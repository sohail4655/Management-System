#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
typedef struct
{
   unsigned int day;
   unsigned int month;
   unsigned  int year;
} Date;
typedef struct
{
   unsigned int id;
    char lastname[50];
    char firstname[50];
    float salary;
    Date birth;
    char adress[30];
    char phonenumber[12];
    char email[20]
} Employee;
int isemail(char email[20])
{
    int i,a=0,b=0;
    for (i=0; i<20; i++)
    {
        if (email[i]=='@')
            a=i;
        else if (email[i]=='.')
            b=i;
    }
    if (a==0 || b==0 || b<a)
        return 0;
    else
        return 1;
}
int isphonenumber(char arr [12])
{
    int i,digit=0;;
    for (i=0; i<12; i++)
    {
        if ( arr[i]>='0' && arr[i]<='9')
            digit++;
    }
    if (digit==11)
        return 1;
    else
        return 0;

}
int isdate(int day,int month,int year)
{
    if (day>=1 && day<=31 && month>=1 && month<=12 &&year>=1970 && year<=2022)
        return 1;
    else
        return 0;


}
int isid(int a)
{
    int i;
    char b[20];
    itoa(a,b,10);
    int n=strlen(b);
   for (i=0; i<n; i++)
    {
        if (isalpha(b[i]))
            return 0;
            break;
    }
    return 1;

}
int isname(char a [50])
{
    int i, n=strlen(a);
    for (i=0; i<n; i++)
    {
        if (!(a[i]<'A' || a[i]>'Z' || a[i]<'a' || a[i]>'z'))
            return 0;
    }
    return 1;
}
int issalary(float c)
{
    if (c<=0)
        return 0;
    return 1;
}
int n;
Employee e[100];
FILE*fp;
void load (char *name)
{
    int i,j,h,k;
    char str[100][200];
    fp= fopen(name,"r");
    if (fp==NULL)
        printf("File not found");
    n=0;
    while (!feof(fp))
    {
        fgets(str[n],200,fp);
        n++;
    }
    for (i=0; i<n; i++)
    {
        char *p=strtok(str[i],",");
        j=0;
        while(p!=NULL)
        {
            if (j==0)
                e[i].id=atoi(p);
            else if (j==1)
                strcpy(e[i].lastname,p);
            else if (j==2)
                strcpy(e[i].firstname,p);
            else if (j==3)
                e[i].salary=atof(p);
            else if (j==4)
                e[i].birth.day=atoi(p);
            else if (j==5)
                e[i].birth.month=atoi(p);
            else if (j==6)
                e[i].birth.year=atoi(p);
            else if (j==7)
                strcpy(e[i].adress,p);
            else if (j==8)
                strcpy(e[i].phonenumber,p);
            else if (j==9)
                strcpy(e[i].email,p);
            p=strtok(NULL,",");
            j++;
        }
    }
    fclose(fp);
    h=n;
    n=0;
    k=0;
     for (i=0;i<h;i++)
    {
        if (e[i].id!=0)
        {
            e[i-k]=e[i];
            n++;
        }
        else
            k++;
    }
    //for (i=0; i<n; i++)
    //printf("%d\n L =%s\n%s\n%f\n%d\n%d\n%d\n%s\n%s\n%s",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);


}
void search ()
{
    int i,flag=0;
    char a [40];
    printf("Enter last name you want to search about: \n");
    gets(a);
    while(!isname(a))
    {
        printf("Enter a valid name:");
         gets(a);
    }
    for (i=0; i < n; i++)
    {
        if(strcasecmp(a,e[i].lastname)==0)
        {
            flag++;
            printf("the employee id:%d\n",e[i].id);
            printf("the employee firstname:%s\n",e[i].firstname);
            printf("the employee salary:%f\n",e[i].salary);
            printf("the employee day:%d\n",e[i].birth.day);
            printf("the employee month:%d\n",e[i].birth.month);
            printf("the employee year:%d\n",e[i].birth.year);
            printf("the employee adress:%s\n",e[i].adress);
            printf("the employee phonenumber:%s\n",e[i].phonenumber);
            printf("the employee email:%s\n",e[i].email);

        }
    }
    if (flag==0)
        printf("There are no employees with this last name \n");
}
void addtofile ()
{
    int x;
    printf("How much additions are there? \n ");
    scanf("%d",&x); //number of added employees

    int i;
    for (i=0; i<x; i++)//for loop to scan the information to be added
    {
        printf("Enter employee ID: ");
        scanf("%d",&e[n+i].id);
        while(!isid(e[n+i].id))
        {
            printf("Enter a valid id:");
            scanf("%d",&e[n+i].id);
        }
        printf("Enter employee last name: ");
        getchar( );
        gets(e[n+i].lastname);
        while(!isname(e[n+i].lastname))
        {
            printf("Enter a valid name:");
            gets(e[n+i].lastname);
        }
        printf("Enter employee first name: ");
        gets(e[n+i].firstname);
        while(!isname(e[n+i].firstname))
        {
            printf("Enter a valid name:");
            gets(e[n+i].firstname);
        }
        printf("Enter employee salary: ");
        scanf("%f",&e[n+i].salary);
        while(!issalary(e[n+i].salary))
        {
            printf("Enter a valid salary:");
        scanf("%f",&e[n+i].salary);
        }
        printf("Enter employee day of birth: ");
        scanf("%d",&e[n+i].birth.day);
        printf("Enter employee month of birth: ");
        scanf("%d",&e[n+i].birth.month);
        printf("Enter employee year of birth: ");
        scanf("%d",&e[n+i].birth.year);
        while(!isdate(e[n+i].birth.day,e[n+i].birth.month,e[n+i].birth.year))
        {
            printf("Enter a valid date\n");
            printf("Enter employee day of birth: ");
            scanf("%d",&e[n+i].birth.day);
            printf("Enter employee month of birth: ");
            scanf("%d",&e[n+i].birth.month);
            printf("Enter employee year of birth: ");
            scanf("%d",&e[n+i].birth.year);
        }
        printf("Enter employee address: ");
        getchar();
        gets(e[n+i].adress);
        printf("Enter employee phone number: ");
        gets(e[n+i].phonenumber);
        while(!isphonenumber(e[n+i].phonenumber))
        {
            printf("Enter a valid phone number:");
            gets(e[n+i].phonenumber);
        }
        printf("Enter employee E-mail:");
        gets(e[n+i].email);
        while(!isemail(e[n+i].email))
        {
            printf("Enter a valid email:");
            gets(e[n+i].email);
        }
    }
    n=n+x;//universal array counter addition
    // for (i=0; i<n; i++)
    //printf("%d %s  %s  %f %d %d %d  %s  %s  %s\n",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);
}
void modifyfile ()
{
    int modid,flag=0,i=0;
    printf("Enter id required to modify: ");
    scanf("%d",&modid);//id input for required to modify entry
    while(!isid(modid))
    {
        printf("Enter a valid id:");
         scanf("%d",&modid);
    }
    for (i=0; i<n; i++)//for loop for checking which element of the array has this id
    {
        if (e[i].id==modid)
        {
            flag=1;//means that the id was found successfully
             printf("Enter new ID: ");
        scanf("%d",&e[i].id);
        while(!isid(e[i].id))
        {
            printf("Enter a valid id:");
            scanf("%d",&e[i].id);
        }
        printf("Enter employee last name: ");
        getchar( );
        gets(e[i].lastname);
        while(!isname(e[i].lastname))
        {
            printf("Enter a valid name:");
            gets(e[i].lastname);
        }
        printf("Enter employee first name: ");
        gets(e[i].firstname);
        while(!isname(e[i].firstname))
        {
            printf("Enter a valid name:");
            gets(e[i].firstname);
        }
        printf("Enter employee salary: ");
        scanf("%f",&e[i].salary);
        while(!issalary(e[i].salary))
        {
            printf("Enter a valid salary:");
        scanf("%f",&e[i].salary);
        }
        printf("Enter employee day of birth: ");
        scanf("%d",&e[i].birth.day);
        printf("Enter employee month of birth: ");
        scanf("%d",&e[i].birth.month);
        printf("Enter employee year of birth: ");
        scanf("%d",&e[i].birth.year);
        while(!isdate(e[i].birth.day,e[i].birth.month,e[i].birth.year))
        {
            printf("Enter a valid date\n");
            printf("Enter employee day of birth: ");
            scanf("%d",&e[i].birth.day);
            printf("Enter employee month of birth: ");
            scanf("%d",&e[i].birth.month);
            printf("Enter employee year of birth: ");
            scanf("%d",&e[i].birth.year);
        }
        printf("Enter employee address: ");
        getchar();
        gets(e[i].adress);
        printf("Enter employee phone number: ");
        gets(e[i].phonenumber);
        while(!isphonenumber(e[i].phonenumber))
        {
            printf("Enter a valid phone number:");
            gets(e[i].phonenumber);
        }
        printf("Enter employee E-mail:");
        gets(e[i].email);
        while(!isemail(e[i].email))
        {
            printf("Enter a valid email:");
            gets(e[i].email);

        }
        break;
     }
    }
    if (flag==0)//means that the id was not found in the array
    {
        printf("Invalid id");
        modifyfile();

    }
}
void print ()
{
    int x ;
    printf(" 1 last name\n 2 salary\n 3 date of birth\n");
    scanf("%d",&x);
    if (x==1)
        sortByLname();
    else if (x==2)
        SortBySalary();
    else if (x==3)
        SortByDOB();

}
void SortBySalary ()
{
    int x, i, j, s =0 ;
    float temp ;
    int day, month, year ;
    Employee b ;
    char ar [100];

    for (i = 1 ; i < n; i++)
    {
        j = i;
        while ( j > 0 && e[j-1].salary < e[j].salary)
        {
            b    = e[j];
            e[j]  = e[j-1];
            e[j-1] = b;
            j--;
        }
    }
    for (int i=0; i<n; i++)
        printf("ID:%d\n Last name: %s\n First name: %s\n Salary: %f\nBirthday %d-%d-%d\n Address: %s\n Phone number:%s\n E-mail:%s\n",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);
}
void SortByDOB()
{
    int x, i, j, s =0 ;
    float temp ;
    int day, month, year ;
    Employee b ;
    char ar [100];
    for (i = 1 ; i < n; i++)
    {
        j = i;
        while ( j > 0 &&  e[j-1].birth.year >= e[j].birth.year )
        {

            b    = e[j];
            e[j]  = e[j-1];
            e[j-1] = b;


            if (e[j].birth.year==e[j-1].birth.year)
            {
                if (e[j-1].birth.month >= e[j].birth.month)
                {
                    b    = e[j];
                    e[j]  = e[j-1];
                    e[j-1] = b;
                }
            }
            if (e[j-1].birth.month == e[j].birth.month)
            {
                if (e[j-1].birth.day >= e[j].birth.day)
                {
                    b    = e[j];
                    e[j]  = e[j-1];
                    e[j-1] = b;
                }

            }

            j--;
        }
    }
    for (int i=0; i<n; i++)
        printf("ID:%d\n Last name: %s\n First name: %s\n Salary: %f\nBirthday %d-%d-%d\n Address: %s\n Phonenumber:%s\n E-mail:%s\n",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);
}
void sortByLname()
{
    int x,i,j, s =0 ;
    float temp ;
    int day, month, year ;
    Employee b ;
    char ar [100];
    for ( j=0; j<n-1; j++)
    {
        for ( i=j+1; i<n; i++)

        {
            if(strcasecmp(e[j].lastname,e[i].lastname)> 0)
            {
                b=e[j];
                e[j]=e[i];
                e[i]=b;
            }
        }
    }

    for (int i=0; i<n; i++)
        printf("ID:%d\n Last name: %s\n First name: %s\n Salary: %f\nBirthday %d-%d-%d\n Address: %s\n Phonenumber:%s\n E-mail:%s\n",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);
}

void deleteemp ()
{
    char firstname[50],lastname[50];
    int i,j,z=0;
    printf("Enter the first name:");
    gets(firstname);
    while(!isname(firstname))
    {
         printf("Enter a valid first name:");
    gets(firstname);
    }
    printf("Enter the last name:");
    gets(lastname);
    while(!isname(lastname))
    {
         printf("Enter a valid last name:");
    gets(lastname);
    }
    for (i=0; i<n; i++)
        for(j=0; j<n; j++)
            if (strcasecmp(e[j].firstname,firstname)==0 && strcasecmp(e[j].lastname,lastname)==0)
                for(j; j<n; j++)
                {
                    z++;
                    e[j]=e[j+1];
                    n--;
                }
            if (z==0)
                printf("Tring to delete an employee that is not in the file");
}
void exitprogram(char*name,char x[3])
{
    if (strcasecmp(x,"yes")==0)
        save(name);
    exit(-1);
}
void save (char*name)
{
    fp= fopen(name,"w");
    int i ;
    char str[100][200];
    for (i=0; i<n; i++)
    {
        snprintf(str[i],200,"%d,%s,%s,%.2f,%d,%d,%d,%s,%s,%s",e[i].id,e[i].lastname,e[i].firstname,e[i].salary,e[i].birth.day,e[i].birth.month,e[i].birth.year,e[i].adress,e[i].phonenumber,e[i].email);
        fprintf(fp,"%s\n",str[i]);
    }
    fclose(fp);

}
int main()
{
    char filename[20],a[50],x[3];
    int y,c=0;
    printf("Enter file name:");
    scanf("%s",filename);
    load(filename);
    while (1)
    {
        printf(" 1.add\n 2.search\n 3.modify\n 4.delete\n 5.sort\n 6.save\n 7.Quit \n");
        scanf("%d",&y);

        switch(y)
        {
        case 1 :
            addtofile();
            c++;
            break ;
        case 2 :
            search();
            c++;
            break ;
        case 3 :
            modifyfile();
            c++;
            break ;
        case 4 :
            c++;
            deleteemp();
            break ;
        case 5 :
            print ();
            c++;
            break;
        case 6 :
            save(filename);
            if(c==0)
                printf("nothing changed");
            exitprogram(filename,x);
            break ;
        case 7 :
            if (c>0)
            {
                printf("Do you want to save the changes?\n");
                scanf("%s",x);
            }
            exitprogram(filename,x);
            break ;
        }
    }
    return 0;
}

